<?php


$person = array(

array("name" => " Christian Ehd S. Garces ", "age" => "21 ", "birth date" => "March 14,2001 ", "address" => "Canduman, Mandaue City ",
 "hobby" => "Playing Basketball and Chess ", "Religion" =>
 "Roman Catholic  ", "id" => "4G-DIET  ")
);






?>



<!DOCTYPE html>
<html>
<head>
	<title>MY BIOGRAPHY</title>
</head>
<body>

  <header>
        <center>
    <div> My Biography </div>

  </center>
     <table border ="1" width="900" align="center">
     <tr>
     	<th> Name </th>
     	<th>Age</th>
     	<th>Birth Date</th>
      <th> Address </th>
      <th>Hobby</th>
      <th>Religion</th>
       <th>I.D</th>
    </tr>

      <?php 

      foreach ($person as $numericField => $data) {
      	print "<tr>";

      	foreach($data as $personfield => $personData){

                print "<td> $personData </td>";
          


            }
            
          
       }
     
      ?>
       
   


     </table>



</body>
</html>
